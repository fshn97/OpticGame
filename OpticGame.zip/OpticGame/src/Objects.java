import java.awt.Graphics;

public abstract class Objects {
	
	public abstract int getX();
	
	public abstract int getY();
	
	public abstract int getAngle();
	
	public abstract void draw(int a, int b, Graphics g);
	
}
