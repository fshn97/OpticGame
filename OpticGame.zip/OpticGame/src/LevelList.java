import java.util.ArrayList;

public class LevelList {

	public static ArrayList<Level> levels = new ArrayList<Level>();
	public static int levelNum = 0;
	
	public LevelList(){
		
		setList();
		
	}
	
	public static void setList(){
		
		Level lvl = new LevelOne();
		Level lvl2 = new LevelTwo();
		
		levels.add(lvl);
		levels.add(lvl2);
		
		
		
	}
	

}
