import java.awt.*;

import javax.swing.*;

public class Tutorials extends JPanel {

	JLabel l1,l2;
	JPanel panel2,panel3;
	
	public Tutorials(){
		
		super();
		
		setLayout(new BorderLayout());
		
		panel3 = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		
		l1 = new JLabel("TUTORIALS");
		panel3.add(l1);
		
		panel2 = new CenterPanel();
		
        add(panel2, BorderLayout.CENTER);
		
		l2 = new JLabel("HEYY");
		
		add(panel3, BorderLayout.NORTH);
		
	}
}
