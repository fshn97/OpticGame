import javax.swing.*;
import java.awt.*;

public class CenterPanel extends JPanel{

	JButton b1,b2,b3,b4,b5;
	JLabel l1,l2,l3,l4,l5;
    JPanel panel2,panel3;
	
    GridBagConstraints gbc = new GridBagConstraints();
    
	public CenterPanel(){
		
		super();
		
        setLayout(new GridBagLayout());
		
		b1 = new JButton("LEVEL 1");
		l1 = new JLabel("PLANE MIRROR");
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		add(b1,gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 1;
		add(l1,gbc);
		
		b2 = new JButton("LEVEL 2");
		l2 = new JLabel("CONVEX MIRROR");
		
		gbc.gridx = 2;
		gbc.gridy = 0;
		add(b2,gbc);
		
		gbc.gridx = 2;
		gbc.gridy = 1;
		add(l2,gbc);
		
		b3 = new JButton("LEVEL 3");
		l3 = new JLabel(" CONCAVE MIRROR");
		
		gbc.gridx = 4;
		gbc.gridy = 0;
		add(b3,gbc);
		
		gbc.gridx = 4;
		gbc.gridy = 1;
		add(l3,gbc);
		
		b4 = new JButton("LEVEL 4");
		l4 = new JLabel("CONVEX LENS");
		
		gbc.gridx = 1;
		gbc.gridy = 7;
		add(b4,gbc);
		
		gbc.gridx = 1;
		gbc.gridy = 8;
		add(l4,gbc);
		
		b5 = new JButton("LEVEL 5");
		l5 = new JLabel("CONVEX LENS");
		
		gbc.gridx = 3;
		gbc.gridy = 7;
	    add(b5,gbc);
	    
	    gbc.gridx = 3;
		gbc.gridy = 8;
		add(l5,gbc);

	}
	
	
public void paintComponent(Graphics g){
		
		super.paintComponent(g);
		
		g.drawLine(0,25 , 5000, 25);
		
	}
}
