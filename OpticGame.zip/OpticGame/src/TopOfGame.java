	import java.awt.*;
	import java.io.File;
	
	import javax.imageio.ImageIO;
	import javax.swing.*;
	
	
	
	public class TopOfGame extends JPanel {
	
		JButton b1;
		JLabel l1;
		int x = 0;
		public TopOfGame(){
			
			super();
			
			setLayout(new FlowLayout(FlowLayout.LEFT));
			
			b1 = new JButton("Back to Level Menu");
			add(b1);
			l1 = new JLabel("                                                                                               LEVEL: " + x);
			add(l1);
		
		
		}
	
	}
