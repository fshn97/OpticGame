import java.awt.BorderLayout;
import java.awt.Graphics;

import javax.swing.JPanel;

public class PlayPanel extends JPanel {
	

	public PlayPanel(){
		
		this.setLayout(new BorderLayout());

		JPanel panel = new Background();
		JPanel panel2 = new TopOfGame();
		JPanel panel3 = new BottomOfGame1();
		
		this.setVisible(true);
		
		this.add(panel,BorderLayout.CENTER);
		this.add(panel2,BorderLayout.PAGE_START);
		this.add(panel3,BorderLayout.PAGE_END);
		
	}
	
}
