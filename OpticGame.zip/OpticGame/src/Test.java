import java.awt.*;
import javax.swing.UIManager.*;
import javax.swing.*;
public class Test extends JFrame {

	static boolean run = true;

	JPanel panel;
	static JPanel panel2;
	JPanel panel3;
	public Test(){
	 
		super();
		
		setLayout(new BorderLayout());
		
	}
	
	public static void main(String[] args) {
		
		try {
		    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
		        if ("Nimbus".equals(info.getName())) {
		            UIManager.setLookAndFeel(info.getClassName());
		            break;
		        }
		    }
		} catch (Exception e) {
		  
		}
		JFrame frame = new Test();
		JPanel panel1 = new JPanel();
		frame.setLayout(new BorderLayout());

		JPanel panel = new Background();
		JPanel panel2 = new TopOfGame();
		JPanel panel3 = new BottomOfGame1();
		
		frame.setVisible(true);
		
		frame.add(panel,BorderLayout.CENTER);
		frame.add(panel2,BorderLayout.PAGE_START);
		frame.add(panel3,BorderLayout.PAGE_END);
		frame.setSize(1607,992);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.add(panel);
		
		frame.setLocationRelativeTo(null);
		
		frame.setResizable(false);
	
	}

}
